# JBD rebuild v1 — Milestone 9.1 test report

Datum: 2026-09-14

## Scope

Milestone 9.1 is een gerichte infantry visual/readability pass bovenop Milestone 9 supply/upgrades en de 9-map campaign.

## Build / syntax

- Alle `src/*.js`: `node --check` geslaagd.
- `node build.js`: geslaagd.
- Gebundelde JavaScript uit `dist/index.html`: syntaxcheck geslaagd.
- Standalone release: geen externe runtime-assets.

## Infantry sprite sets

Runtime gecontroleerd:

- stand: 4 frames;
- walk: 8 frames;
- fire: 4 frames;
- crouch: 4 frames;
- prone: 6 frames;
- swim: 6 frames;
- twee death poses;
- los emplacement sprite voor engineer / gun-team.

De sprites zijn opnieuw opgebouwd als top-down silhouettes: helm van boven, schouders / backpack, duidelijke rifle-richting en bewegende benen.

## State / pose checks

390 × 844 mobile Chromium emulation, deviceScaleFactor 2:

- `DEPLOY` start de game correct;
- rifleman zonder echte cover in firing state kiest `fire` pose;
- infantry midden in rivier kiest `swim` pose en `inWater=true`;
- prone blijft beschikbaar voor echte cover states;
- mounted weapon / engineer renderpad uitgevoerd;
- 0 geobserveerde uncaught JavaScript exceptions.

## Performance sample

Tijdens de mobiele runtime-smoketest stabiliseerde `fpsSmoothed` rond 60 FPS in de gecontroleerde scene.

## Visual inspection

Afzonderlijk gecontroleerd in een pose sheet én in het echte Jungle battlefield:

- walk leest duidelijk anders dan stand;
- firing stance heeft rifle naar voren;
- crouch is laag en breed;
- prone is lang/plat in de bewegingsrichting;
- swim toont enkel bovenlichaam/helm met water-wake;
- corpse poses zijn gespreid en niet allemaal buikliggend.

## Niet geclaimd

- Geen fysieke iPhone Safari benchmark vanuit deze runtime.
- Definitieve artistieke smaak blijft afhankelijk van on-device beoordeling op het echte iPhone-scherm.
