# JBD — Bunker Defense · Rebuild v1

Current release: **Milestone 9.1 — Infantry Visual Pass**.

Milestone 9 adds the persistent supply / upgrade loop. Milestone 9.1 keeps that gameplay intact and rebuilds infantry readability for the top-down battlefield.

## Spelen

Open `dist/index.html`. De release is één standalone HTML-bestand zonder externe runtime-assets.

## Campaign

De vaste volgorde blijft:

`JUNGLE 1 → JUNGLE 2 → JUNGLE 3 → DESERT 1 → DESERT 2 → DESERT 3 → POLAR 1 → POLAR 2 → POLAR 3`

Na `POLAR 3` start `JUNGLE 1` opnieuw als Cycle 2.

## Milestone 9 / 9.1

- Supply rewards na iedere cleared map.
- Persistent upgrade shop tussen maps via localStorage.
- Upgrades voor caliber, burst, charge speed, HE blast en armor.
- Bunker HP / damage resistance / barrel / sandbags reageren op upgrades.
- Infantry gebruikt nu echte top-down silhouettes die visueel aansluiten op voertuigen en terrein.
- Aparte sprite-sets voor:
  - upright walk;
  - stand;
  - firing stance;
  - crouch;
  - prone / crawl;
  - swim;
  - meerdere death poses.
- Open terrein gebruikt een staande firing pose in plaats van automatisch prone/crouch.
- Prone blijft gekoppeld aan echte cover / suppression situaties.
- Zwemmers hebben een duidelijke water-wake.
- Engineer / gun-team kan een los mounted weapon opstellen en gebruiken.

## Map generation / gameplay

- Elke scenario rebuildt terrein, rivier, twee bruggen, wegen, gebouw, loopgraven, vegetatie en obstakels.
- Voertuigen routeren via bruggen en rijden niet vrij door de rivier.
- Infantry kan zwemmen en beweegt in water op ongeveer 46% snelheid.
- Jungle, Desert en Polar hebben eigen cover / zichtlijn / voertuigkarakter.
- Airborne blijft onderdeel van de campagne.
- Mobile entity scale blijft 72% op smalle schermen, met ruime touch hitboxes en DPR cap 1.65.

## Build

`node build.js`

Genereert `dist/index.html` uit de modules in `src/`.

## Debug

`?debug=1` toont FPS/state overlays. `?stress=1` start de zware stress-scène binnen de huidige campaign-map.
